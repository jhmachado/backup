<?php

class ClienteService {

    private $clienteRepository;

    public function __construct(){
        $this->clienteRepository = new ClienteRepository();
    }

    public function salvar(Cliente $cliente){
        return $this->clienteRepository->save($cliente);
    }


    public function alterar(Cliente $cliente){
        return;
    }

    public function deletar(Cliente $cliente){
        return $this->clienteRepository->deletar($cliente);
    }
}