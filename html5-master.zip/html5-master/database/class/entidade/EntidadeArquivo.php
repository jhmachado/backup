<?php

class EntidadeArquivo {

    public $nomeArquivo;
    public $nomeOriginal;
    public $formato;
    public $tamanho;

    public function __construct(){
        settype($this->nomeArquivo, "string");
        settype($this->nomeOriginal, "string");
        settype($this->formato, "string");
        settype($this->tamanho, "string");
    }
}