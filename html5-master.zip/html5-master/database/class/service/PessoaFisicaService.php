<?php

class PessoaFisicaService {

    private $pessoaFisicaRepository;

    public function __construct(){
        $this->pessoaFisicaRepository = new PessoaFisicaRepository();
    }

    public function salvar(PessoaFisica $pessoaFisica){
        $pessoaFisica->setUltimaModificacao();
        return $this->pessoaFisicaRepository->save($pessoaFisica);
    }

    public function listar(PessoaFisica $pessoaFisica){
        return $this->pessoaFisicaRepository->findAll($pessoaFisica);
    }

    public function buscar(PessoaFisica $pessoaFisica){
        return $this->pessoaFisicaRepository->findById($pessoaFisica);
    }

    public function alterar(PessoaFisica $pessoaFisica){
        $pessoaFisica->setUltimaModificacao();
        return $this->pessoaFisicaRepository->update($pessoaFisica);
    }

    public function deletar(PessoaFisica $pessoaFisica){
        return $this->pessoaFisicaRepository->delete($pessoaFisica);
    }
} 