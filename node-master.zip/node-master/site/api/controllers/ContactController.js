/**
 * ContactController
 *
 * @description :: Server-side logic for managing contacts
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {

    findAll : function(req, res) {

        Contact.find().exec(function (err, contacts) {
            if (err) return res.negotiate(err);

            return res.view('admin/contact/list', {
                layout : 'adminLayout',
                contacts : contacts
            });
        })

    }

};

