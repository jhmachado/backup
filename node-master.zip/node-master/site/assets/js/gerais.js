/**
 * Created by jhonatan on 20/12/2015.
 */

function quebrar_texto(texto, tamanho){
    var array = texto.split(" ");
    var cont = 0;
    var result = "";

    for(var i = 0; i < array.length; i++){
        cont += array[i].length + 1;

        if(tamanho >= cont){
            result += array[i] + " ";
        }
    }
    return result;
}