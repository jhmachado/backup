/**
 * Created by jhonatan on 19/12/2015.
 */

module.exports.myconfig = {

    name : 'Personal Web Site',
    author : 'Jhonatan H. D. Machado',

    globalVariables : {
        path : 'http://localhost:1337'
    }

};
