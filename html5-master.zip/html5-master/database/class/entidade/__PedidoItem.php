<?php

class PedidoItem extends Entidade{

    /*
     * @param Produto $produto
     * @param float $desconto
     */

    public $produto;
    public $desconto;

}