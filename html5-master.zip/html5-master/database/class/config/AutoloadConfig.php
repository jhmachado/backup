<?php

class AutoloadConfig {

    public $pasta;
    public $proximaPasta;

    public function __construct($pasta){
        $this->pasta = $pasta;
        $this->proximaPasta = $pasta;
        $this->pasta .= "class/config";
        spl_autoload_register(array($this, 'loader'));
    }

    public function loader($className){
        $nomeArquivo = "$this->pasta/".$className . '.php';
        if(is_file($nomeArquivo)) {
            include $nomeArquivo;
        }else{
            $this->proximo();
        }
    }

    public function proximo(){
        return "Classe não encontrada";
    }
}