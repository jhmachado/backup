package aula20140808.ddd.associacoesComReferencias;

public class Uf {
	private Long id;
	private Pais pais;
	
	public Long getId() {
		return id;
	}
	public Pais getPais() {
		return pais;
	}
	
	

}
