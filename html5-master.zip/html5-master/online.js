function isSiteOnline(){
    return true;
}
