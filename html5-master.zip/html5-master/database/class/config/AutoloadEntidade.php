<?php

class AutoloadEntidade extends Autoload{

    public $autoloadService;
    public $pasta;
    public $proximaPasta;

    public function __construct($pasta){
        $this->pasta = $pasta;
        $this->proximaPasta = $pasta;
        $this->pasta .= "class/entidade";
        spl_autoload_register(array($this, 'loader'));
    }

    public function loader($className){
        $nomeArquivo = "$this->pasta/".$className . '.php';
        if(is_file($nomeArquivo)) {
            include $nomeArquivo;
        }else{
            $this->proximo();
        }
    }

    public function proximo(){
        require_once 'AutoloadService.php';
        $this->autoloadService = new AutoloadService($this->proximaPasta);
    }
}