<?php

class ConfigService {

    private $configRepository;

    public function __construct(){
        $this->configRepository = new ConfigRepository();
    }

    public function buscar(Config $config){
        return $this->configRepository->findById($config);
    }

    public function alterar(Config $config){
        $config->setUltimaModificacao();
        return $this->configRepository->update($config);
    }
}