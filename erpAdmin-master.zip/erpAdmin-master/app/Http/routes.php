<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

//Route::get('/login', function () {
//    return view('login');
//});

Route::get('/login', 'Auth\AuthController@getLogin');
Route::post('/login', 'Auth\AuthController@postLogin');
Route::get('/logout', 'Auth\AuthController@getLogout');

//Route::group(['middleware' => 'web'], function () {
//    Route::auth();

    Route::get('/', 'HomeController@index');

    Route::get('/usuarios', 'UserController@index');
    Route::get('/usuarios/form', 'UserController@index');
    Route::get('/usuarios/form/{id}', 'UserController@index');

    Route::get('/clientes', 'ClienteController@allClientes');
    Route::get('/clientes/form', 'ClienteController@novoCliente');
    Route::post('/clientes/form', 'ClienteController@salvarCliente');

    Route::get('/clientes/form/{id}', 'ClienteController@getCliente');
    Route::post('/clientes/form/{id}', 'ClienteController@updateCliente');

    Route::get('/modulos', 'ModuloController@index');
    Route::get('/modulos/form', 'ModuloController@index');
    Route::get('/modulos/form/{id}', 'ModuloController@index');
//});
