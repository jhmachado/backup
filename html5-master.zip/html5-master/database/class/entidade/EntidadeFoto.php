<?php

class EntidadeFoto {

    public $nomeFoto;
    public $width;
    public $height;
    public $tamanho;

    public function __construct(){
        settype($this->nomeFoto, "string");
        settype($this->width,    "string");
        settype($this->height,   "string");
        settype($this->tamanho,  "string");
    }
} 