package aula20140801;

import java.math.BigDecimal;
import java.util.Date;

public class Saque extends Movimento {

	public Saque(BigDecimal valor, Date data) {
		super(valor, data);
	}
	
	

}
