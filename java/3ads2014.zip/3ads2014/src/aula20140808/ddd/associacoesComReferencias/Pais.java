package aula20140808.ddd.associacoesComReferencias;

import java.util.List;

public class Pais {
	private Long id;
	private List<Uf> ufs;
	
	public Long getId() {
		return id;
	}
	public List<Uf> getUfs() {
		return ufs;
	}
	
	

}
