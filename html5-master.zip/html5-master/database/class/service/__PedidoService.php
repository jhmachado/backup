<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 07/01/15
 * Time: 22:09
 */

class PedidoService {

}