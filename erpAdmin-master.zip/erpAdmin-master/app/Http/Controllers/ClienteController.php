<?php

namespace App\Http\Controllers;

use App\Cliente;
use App\Http\Controllers\Controller;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;

class ClienteController extends Controller{

    protected $cliente;

    public function __construct(Cliente $cliente)
    {
        $this->cliente = $cliente;
    }

    public function allClientes()
    {
        $clientes = $this->cliente->allClientes();
        return view('cliente.lista', ['clientes' => $clientes]);
    }

    public function novoCliente()
    {
        return view('cliente.form', ['cliente' => new Cliente()]);
    }

    public function getCliente($id)
    {
        $cliente = $this->cliente->getCliente($id);
        if (!$cliente)
        {
            return response()->json(['response' => 'Cliente não encontrado!'], 400);
        }

        return response()->json($cliente, 200);
    }

    public function salvarCliente()
    {
        return response()->json($this->cliente->saveCliente(), 200);
    }

    public function updateCliente($id)
    {
        $cliente = $this->cliente->updateCliente($id);
        if (!$cliente)
        {
            return response()->json(['response' => 'Cliente não encontrado!'], 400);
        }

        return response()->json($cliente, 200);
    }

    public function deleteCliente($id)
    {
        $cliente = $this->cliente->deleteCliente($id);
        if (!$cliente)
        {
            return response()->json(['response' => 'Cliente não encontrado!'], 400);
        }

        return response()->json(['response' => 'Cliente removido com sucesso!'], 200);
    }
} 