<?php

class FornecedorRepository extends TRepository{
    public function __construct(){
        parent::__construct();
    }
}