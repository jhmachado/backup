<?php

class NewsletterRepository extends TRepository{
    public function __construct(){
        parent::__construct();
    }
}