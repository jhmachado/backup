package aula20140808.ddd.associacoesComIDs;

public class PaisRepository {

	public Pais findById(Long paisId) {
		// TODO Auto-generated method stub
		return null;
	}

}
