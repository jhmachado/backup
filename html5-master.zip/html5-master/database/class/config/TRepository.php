<?php

abstract class TRepository {

    public $conexao;
    public $order;
    public $chavesEstrangeiras;
    public $arquivos;

    public function __construct(){
        $this->conexao = new Conexao();
        $this->chavesEstrangeiras = array();
        $this->arquivos = array();
    }

    public function findById($object){
        $class = get_class($object);
        $vars = get_object_vars($object);
        $binds = array_keys($vars);

        $sql = "select ";
        $sql .= implode(", ", $binds);
        $sql .= " from " . strtolower($class);
        $sql .= " WHERE id = $object->id";

        return $this->conexao->queryObject($sql, $class);
    }

    public function findAll($object, $pagina, $limit = 5){
        $pular = ($pagina - 1) * $limit;
        $retorno = array(
            'anterior' => '',
            'lista' => '',
            'paginas' => '',
            'proxima' => ''
        );

        if($pagina > 1){
            $retorno['anterior'] = $pagina - 1;
        }

        $class = get_class($object);
        $vars = get_object_vars($object);


        foreach ($this->chavesEstrangeiras as $chave) {
            unset($vars[$chave]);
        }

        $binds = array_keys($vars);

        $sql = "SELECT ";
        $sql .= implode(", ", $binds);
        $sql .= " FROM " . strtolower($class);
        $sql .= " ORDER BY $this->order";
        $sql .= " LIMIT $pular, $limit; ";

        $retorno['lista'] =  $this->conexao->queryArray($sql, $class);

        $sqlPaginacao = "SELECT count(id) as id FROM " . strtolower($class);
        $retorno['paginas'] = $this->conexao->query($sqlPaginacao);

        return $retorno;
    }

    public function save($object){
        if(is_null($object)){
            return null;
        }

        unset($object->id);

        $class = get_class($object);
        $vars = get_object_vars($object);

        foreach ($this->chavesEstrangeiras as $chave) {
            unset($object->$chave);
        }

        $idPrincipal = $this->insert($object);

        foreach ($this->chavesEstrangeiras as $chave) {
            $objectFK = $vars[$chave];
            $objectFK->set(strtolower($class)."FK", $idPrincipal, "INT");
            $this->insert($objectFK);
        }

        return true;
        #echo "Classe = $class";
    }

    public function insert($object){
        $class = get_class($object);
        $vars = get_object_vars($object);
        $binds = array_keys($vars);

        $sql = "INSERT INTO ". strtolower($class);
        $sql .= "(".implode(", ", $binds).") values (";

        foreach($binds as $key => $valor){
            $terms[] = ":" . $valor;
        }

        $sql .= implode(", ", $terms);
        $sql .= ")";

        echo $sql;
        #echo "Salvando - $class -  $sql <br />";
        return $this->conexao->query($sql, $vars);
    }

    public function update($object){
        $id = $object->id;
        unset($object->id);

        $class = get_class($object);
        $vars = get_object_vars($object);
        $binds = array_keys($vars);

        $sql = "UPDATE " . strtolower($class) . " set ";
        foreach($binds as $key => $valor){
            $terms[] = $valor . " = :" . $valor;
        }

        $sql .= implode(", ", $terms);
        $sql .= " WHERE id = $id";

        return $this->conexao->query($sql, $vars);
    }

    public function delete($object){
        $class = get_class($object);
        $sql = "DELETE FROM " . strtolower($class);
        $sql .= " WHERE id = " . $object->id;
        return $this->conexao->query($sql);
    }

}