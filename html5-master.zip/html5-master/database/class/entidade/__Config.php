<?php

class Config extends Entidade {

    public $nome;
    public $email;
    public $telefone1;
    public $telefone2;
    public $endereco;
    public $numero;
    public $bairro;
    public $cep;
    public $cidade;
    public $estado;


    public function __construct(){
        settype($this->nome,      "string");
        settype($this->email,     "string");
        settype($this->telefone1, "string");
        settype($this->telefone2, "string");
        settype($this->endereco,  "string");
        settype($this->numero,    "string");
        settype($this->bairro,    "string");
        settype($this->cep,       "string");
        settype($this->cidade,    "string");
        settype($this->estado,    "string");
    }
}