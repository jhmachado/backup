package aula20140805;

public class MovimentoReporitoryFactory {

	public static MovimentoRepository createRepository() {		
		return new MovimentoRepositoryInMemory();
	}

}
