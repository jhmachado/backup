<?php

abstract class Autoload {

    public $pasta;
    abstract public function loader($className);
    abstract public function proximo();

}