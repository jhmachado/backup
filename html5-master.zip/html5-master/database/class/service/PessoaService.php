<?php

class PessoaService {

    private $pessoaRepository;
    private $pessoaFisicaService;
    private $pessoaJuridicaService;

    public function __construct(){
        $this->pessoaRepository = new PessoaRepository();
        $this->pessoaFisicaService = new PessoaFisicaService();
        $this->pessoaJuridicaService = new PessoaJuridicaService();
    }

    public function salvar(Pessoa $pessoa){
        /*$idPessoaFisica = $this->pessoaFisicaService->salvar($pessoa->PessoaFisica);
        unset($pessoa->PessoaFisica);
        $pessoa->set("pessoafisicaFK", $idPessoaFisica, "int");

        $idPessoaJuridica = $this->pessoaJuridicaService->salvar($pessoa->PessoaJuridica);
        unset($pessoa->PessoaJuridica);
        $pessoa->set("pessoajurificaFK", $idPessoaJuridica, "int");
          */
        $pessoa->setUltimaModificacao();

        return $this->pessoaRepository->save($pessoa);
    }

    public function listar(Pessoa $pessoa, $pagina){
        return $this->pessoaRepository->findAll($pessoa, $pagina);
    }

    public function buscar(Pessoa $pessoa){
        return $this->pessoaRepository->findById($pessoa);
    }

    public function alterar(Pessoa $pessoa){
        $pessoa->setUltimaModificacao();
        return $this->pessoaRepository->update($pessoa);
    }

    public function deletar(Pessoa $pessoa){
        return $this->pessoaRepository->delete($pessoa);
    }
} 