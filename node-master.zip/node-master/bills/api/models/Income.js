/**
 * Income.js
 *
 * @description :: TODO: You might write a short summary of how this model works and what it represents here.
 * @docs        :: http://sailsjs.org/#!documentation/models
 */

module.exports = {

    attributes: {
        code : {
            type : 'integer',
            autoIncrement : true
        },

        title : {
            type : 'string',
            required : true,
            size : 255
        },

        date : {
            type : 'date',
            required : true
        },

        value : {
            type : 'float',
            decimal2 : true,
            required : true
        }
    },

    types: {
        decimal2: function(number){
            return ((number *100)%1 === 0);
        }
    },

    connection: 'mongodb'
};

