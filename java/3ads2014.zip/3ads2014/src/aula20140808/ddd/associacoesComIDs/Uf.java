package aula20140808.ddd.associacoesComIDs;

public class Uf {
	private Long id;
	private Long paisId;
	private PaisRepository repoPais;
	//private Pais pais;
	
	public Long getId() {
		return id;
	}
	public Pais getPais() {
		return repoPais.findById(paisId);
	}
	
	

}
