<?php

class Pessoa extends Entidade{

    /*
     *  @param string nome da pessoa - $nome
     *  @param string email da pessoa - $email
     *  @param object PessoaFisica relacionamento   com o cadastro atual - $PessoaFisica
     *  @param object PessoaJuridica relacionamento com o cadastro atual - $PessoaJuridica
     */

    public $nome;
    public $email;
    public $fotos;
    public $PessoaFisica;
    public $PessoaJuridica;

    public function __construct(){
        settype($this->nome, "string");
        settype($this->email, "string");
        settype($this->fotos, "array");

        $this->PessoaFisica = new PessoaFisica();
        $this->PessoaJuridica = new PessoaJuridica();
    }
} 