<?
$controller = $_GET['id']."/".$_GET['pg'].".php";
if(file_exists($controller)){
    include $controller;
}else{
    echo "nao entrou aqui";
}