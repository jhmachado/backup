<?php

class Entidade {
    /*
     * @param int @id
     * @param Id $id
     * @param datetime $ultimaModificacao
     * @param int @excluido
     */
    public $id;
    public $ultimaModificacao = 'now()';
    public $excluido = 0;


    public function __construct(){
        settype($this->id, "int");
        settype($this->ultimaModificacao, "string");
        settype($this->excluido, "int");
    }

    public function set($atributo, $valor, $tipo){
        $this->$atributo = $valor;
        settype($this->$atributo, $tipo);
    }

    public function serializeArray($classe, array $array){
        $classe = ucfirst($classe);
        $atributos = get_class_vars($classe);

        foreach ($array as $key => $valor) {
            if(is_array($valor)){
                $key = ucfirst($key);
                $this->$key = new $key();
                $this->$key->serializeArray($key, $valor);
                continue;
            }

            if(array_key_exists($key, $atributos)){
                $this->$key = $array[$key];
            }
        }
    }

    public function setUltimaModificacao(){
        $this->ultimaModificacao = date('Y-m-d H:i:s');
    }

}