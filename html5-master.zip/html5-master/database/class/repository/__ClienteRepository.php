<?php

class ClienteRepository extends TRepository{

    public function __construct(){
        parent::__construct();
    }

}