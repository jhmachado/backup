<?php

class Usuario extends Entidade{

    /*
     * @param string $nome
     * @param string $senha
     */
    public $nome;
    public $senha;

    public function __construct(){
        settype($this->nome, "string");
        settype($this->senha, "string");
    }

    public function setMd5(){
        $this->senha = md5($this->senha);
    }

}