package aula20140808.ddd.reflection;

import java.util.List;

public interface PaisRepository {
	
	List<Pais> findBySiglaAndNome(String sigla, String nome);
	List<Pais> findBySiglaAndNomeOrIdOrderByDesc(String sigla, String nome, Long id);

}
