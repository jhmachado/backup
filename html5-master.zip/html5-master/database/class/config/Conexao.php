<?php

class Conexao {

    public $_con;
    public $host;
    public $database;
    public $user;
    public $pass;

    public function __construct(){

        $this->lerDadosConexao();
        try{
            $dsn = "mysql:dbname=".$this->database.";host=".$this->host;
            $this->_con = new PDO($dsn, $this->user, $this->pass);
            $this->_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        }catch (PDOException $e){
            echo "Não foi possível conectar ao banco de dados = " . $e->getMessage();
            exit();
        }
    }

    public function lerDadosConexao(){
        $dados = parse_ini_file(PASTA."class/config/database/conexao.ini");
        $this->host = $dados['host'];
        $this->database = $dados['database'];
        $this->user = $dados['user'];
        $this->pass = $dados['pass'];
    }

    public function query($statement, $binds = array()){
        try{
            $query = $this->_con->prepare($statement);
            foreach ($binds as $key => $bind){
                if(!is_array($bind)){
                    $query->bindValue(":$key", $bind);
                }
            }
            $query->execute();
            $resultado = $query->fetch(PDO::FETCH_ASSOC);
            return $resultado['id'];
        }catch (PDOException $e){
            echo "Erro ao executar query - ".$e->getMessage() . " - $statement";
        }
    }

    public function queryObject($statement, $class){
        try{
            $query = $this->_con->prepare($statement);
            $query->execute();
            return $query->fetchObject($class);
        }catch (PDOException $e){
            echo "Erro ao executar query - ".$e->getMessage();
        }
    }

    public function queryArray($statement, $class){
        try{
            $query = $this->_con->prepare($statement);
            $query->execute();
            return $query->fetchAll(PDO::FETCH_CLASS, $class);
        }catch (PDOException $e){
            echo "Erro ao executar query - ".$e->getMessage() . " - $statement";
        }
    }
}