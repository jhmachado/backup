package aula20140808.ddd.associacoesComIDs;

import java.util.ArrayList;
import java.util.List;

public class Pais {
	private Long id;
	//private List<Uf> ufs;
	private UfRepository repoUf;
	
	public Long getId() {
		return id;
	}
	public List<Uf> getUfs() {
		return repoUf.findByPaisId(this.id);
	}
	
	

}
