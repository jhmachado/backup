<?php

class NewsletterService {

    private $newsletterRepository;

    public function __construct(){
        $this->newsletterRepository = new NewsletterRepository();
    }

    public function salvar(Newsletter $newsletter){
        $newsletter->setUltimaModificacao();
        return $this->newsletterRepository->save($newsletter);
    }

    public function listar(Newsletter $newsletter){
        return $this->newsletterRepository->findAll($newsletter);
    }

    public function buscar(Newsletter $newsletter){
        return $this->newsletterRepository->findById($newsletter);
    }

    public function alterar(Newsletter $newsletter){
        $newsletter->setUltimaModificacao();
        return $this->newsletterRepository->update($newsletter);
    }

    public function deletar(Newsletter $newsletter){
        return $this->newsletterRepository->delete($newsletter);
    }
}