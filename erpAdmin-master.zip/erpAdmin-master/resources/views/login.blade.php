<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>ERP Admin</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS ================================================== -->
    <link rel="stylesheet" href="lib/css/style.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

    <!-- FONTS ================================================== -->

    <!-- Favicons ================================================== -->
    <link rel="shortcut icon" href="imagem/favicon.ico">

    <script src="lib/js/jquery.min.js"></script>
    <script src="lib/js/jquery-ui.min.js"></script>
    <script src="lib/js/libs/bootstrap.min.js"></script>
    <script src="lib/js/libs/waypoints.js"></script>
    <script src="lib/js/libs/jquery.counterup.min.js"></script>
    <script src="lib/js/libs/chosen.jquery.min.js"></script>
    <script src="lib/js/libs/input.slider.js"></script>
    <script src="lib/js/libs/bxslider.js"></script>
    <script src="lib/js/libs/prettyCheckable.min.js"></script>
    <script src="lib/js/libs/jquery.dataTables.min.js"></script>
    <script src="lib/js/libs/chartist/chartist.min.js"></script>
    <script src="lib/js/libs/chartist/chartist-plugin-tooltip.js"></script>
    <script src="lib/js/libs/datepicker/moment.min.js"></script>
    <script src="lib/js/libs/datepicker/bootstrap-datetimepicker.min.js"></script>
    <script src="lib/js/libs/jquery.matchHeight-min.js"></script>
    <script src="lib/js/libs/jquery.fileupload.js"></script>
    <script src="lib/js/libs/fileStyle.js"></script>
    <script src="lib/js/libs/tagsInput.js"></script>
    <script src="lib/js/plugins.js"></script>
    <script src="lib/js/charts.js"></script>
    <script src="lib/js/upload.js"></script>
    <script src="lib/js/app.js"></script>

    {{--<script src="lib/js/angular.js"></script>--}}
    {{--<script src="lib/js/appAdmin.js"></script>--}}
    {{--<script src="lib/js/controller/clienteController.js"></script>--}}

</head>
<body id="app-layout">
    <header class="clearfix">
        <div id="mensagemPrincipal"></div>
        <div class="search right clearfix"></div>
    </header>

    <div id="wrapper" class="clearfix expand">
        <div id="login">
            <div class="fake-table">
                <div class="fake-table-cell">
                    <div id="login">
                        <div class="top left clearfix">
                            <div class="logo left">
                                <img src="lib/imagem/id-logo.png" alt="logo">
                            </div>
                            <p>ERP ADMIN - <span>LOGIN</span></p>
                        </div>

                        <form class="clearfix" action="" method="post">
                            <div class="fields">

                                <fieldset>
                                    <input type="text" name="email" maxlength="255" autocomplete="off" placeholder="Login">
                                    <span><i class="fa fa-user"></i></span>
                                </fieldset>

                                <fieldset>
                                    <input type="password" name="password" maxlength="255" placeholder="SENHA">
                                    <span><i class="fa fa-key"></i></span>
                                </fieldset>

                                <input type="submit" name="logar" value="OK">
                            </div>
                        </form>

                        @if(!empty($erro))
                            <div class="alerts">
                                <div class="error"><p><strong>{{$erro}}</strong> </p></div>
                            </div>
                        @endif

                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>