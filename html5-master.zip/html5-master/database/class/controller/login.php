<?php

header('Content-Type: text/html; charset=utf-8');

define("PASTA", "d:/httpc/html5/database/");
define("PATH", "http://localhost/html5/database/");
date_default_timezone_set('UTC');

include(PASTA . "class/config/Autoload.php");
include(PASTA . "class/config/AutoloadEntidade.php");

$autoload = new AutoloadEntidade(PASTA);

$postdata = file_get_contents("php://input");
$request = json_decode($postdata, true);

$usuario = new Usuario();
$usuario->serializeArray("Usuario", (array) $request);
//$anotacaoService = new AnotacaoService();
//
$method = $_GET['sub'];
call_user_func($method, $usuario);

function logar($usuario){
    echo json_encode(array("status" => true, "user" => 1));
}