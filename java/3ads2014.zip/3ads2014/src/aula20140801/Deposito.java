package aula20140801;

import java.math.BigDecimal;
import java.util.Date;

public class Deposito extends Movimento {

	public Deposito(BigDecimal valor, Date data) {
		super(valor, data);
	}

}
