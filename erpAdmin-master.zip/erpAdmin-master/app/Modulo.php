<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;


class Modulo extends Model
{
    protected $hidden = [''];

    protected $fillable = ['titulo', 'descricao'];

    public function allModulos()
    {
        return self::all();
    }

    public function saveModulo()
    {
        $input = Input::all();

        $rules = [
            'titulo' => 'required|min:3|max:255'
        ];

        $validator = Validator::make($input, $rules);
        if($validator->fails())
        {
            return $validator;
        }

        $modulo = new Modulo();
        $modulo->fill($input);
        $modulo->save();

        return $modulo;
    }

    public function getModulo($id)
    {
        $modulo = self::findOrNew($id);
        if (empty($modulo->titulo))
        {
            return false;
        }

        return $modulo;
    }

    public function updateModulo($id)
    {
        $modulo = self::findOrNew($id);
        if(empty($modulo->titulo))
        {
            return false;
        }

        $input = Input::all();
        $modulo->fill($input);
        $modulo->save();
        return $modulo;
    }

    public function deleteModulo($id)
    {
        $modulo = self::findOrNew($id);
        if (empty($modulo->login))
        {
            return false;
        }

        return $modulo->delete();
    }

} 