var controllers = angular.module('controllers', []);

function ExpendituresController($scope, $http){

    $scope.path = window.location.protocol + "//" + window.location.host + "/";

    $scope.current = {};
    $scope.expenditures = [];

    $scope.init = function()  {
        console.log('init', $scope.path);
    };

    io.socket.get('/expenditure', function(data){
        $scope.expenditures = data;
        $scope.$apply();
    });


    io.socket.on('expenditure', function(event){
        console.log('socket', event)
        switch(event.verb){
            case 'created':
                $scope.expenditures.push(event.data);
                $scope.$apply();
                break;
        }

    });

    $scope.saveExpenditure = function() {

        var path = $scope.path + "expenditure/create/";

        $http.post(path, $scope.current)
            .success(function(data, status){
                console.log(data);
            })
            .error(function(data){
                console.log(data);
            });
    };

}

controllers.controller('ExpendituresController', ['$scope, $http', ExpendituresController]);