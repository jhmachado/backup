<?php

class FornecedorService {

    private $fornecedorRepository;

    public function __construct(){
        $this->fornecedorRepository = new FornecedorRepository();
    }

    public function salvar(Fornecedor $fornecedor){
        return $this->fornecedorRepository->save($fornecedor);
    }


    public function alterar(Cliente $cliente){
        return;
    }

    public function deletar(Fornecedor $fornecedor){
        return $this->fornecedorRepository->deletar($fornecedor);
    }
}