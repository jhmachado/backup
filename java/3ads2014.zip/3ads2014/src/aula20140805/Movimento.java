package aula20140805;

import java.math.BigDecimal;
import java.util.Date;

public class Movimento {
	private final BigDecimal valor;
	private final Date data;
	
	public Movimento(BigDecimal valor, Date data) {
		this.valor = valor;
		this.data = data;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public Date getData() {
		return data;
	}

}
