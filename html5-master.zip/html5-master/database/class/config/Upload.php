<?php

class Upload {

    public $object;
    public $origem;
    public $destino;
    public $extensoes;

    public function __construct($object){
        $this->object = $object;

        $classe = get_class($this->object);
        $this->destino = PASTA . $classe . "files/";

        $this->extensoes = array("jpg", "jpeg", "png", "gif", "doc", "docx", "xls", "xlsx", "pdf", "txt", "ppt", "pptx", "pps", "ppsx", "swf");
    }

    public function validaArquivos($arrayArquivos){


    }

    public function moverArquivo($arrayArquivos){
        foreach ($arrayArquivos as $arquivo) {

        }
    }
} 