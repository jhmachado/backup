package aula20140808.ddd.reflection;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class RepositoryFactory {

	public static Object newInstance(Class classe) {
		
		ClassLoader loader = RepositoryFactory.class.getClassLoader();		
		Class[] interfaces = {classe};
		
		InvocationHandler handler = criarHandler();
		
		return Proxy.newProxyInstance(loader, interfaces, handler);
	}

	private static InvocationHandler criarHandler() {		
		InvocationHandler ih = new InvocationHandler() {			
			@Override
			public Object invoke(Object obj, Method m, Object[] args)
					throws Throwable {
				if (m.getName().startsWith("findBy")) {
					System.out.println("Olha, chamou o m�todo: " + m.getName());
					for (Object arg : args) {
						System.out.println("  ==> " + arg );
					}
				}

				return null;
			}
		};
		return ih;
	}

}
