<header class="clearfix">
    <div class="user left clearfix">
        <div class="avatar left"><img src="images/avatar.png" alt="user"></div>
        <p>JOHN DOE<br><span>MANAGER</span></p>
        <a href="03-01-login.php" class="logout right"><i class="fa fa-power-off"></i></a>
    </div>
    <div class="search right clearfix">
        <a href="#" class="options left"><i class="fa fa-cog"></i></a>
        <form class="right">
            <input type="text" placeholder="SEARCH...">
            <button type="submit">
                <i class="fa fa-search"></i>
            </button>
        </form>
    </div>
</header>