<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;


class Cliente extends Model
{
    protected $hidden = [''];

    protected $fillable = ['nome', 'cookie', 'mysql_host', 'mysql_pass', 'mysql_base'];

    public function allClientes()
    {
        return self::all();
    }

    public function saveCliente()
    {
        $input = Input::all();
        $rules = [
            'nome' => 'required|min:3|max:255',
            'cookie' => 'required|min:3|max:255|unique:clientes',
            'mysql_host' => 'required|min:3|max:255',
            'mysql_pass' => 'required|min:3|max:255',
            'mysql_base' => 'required|min:3|max:255',
        ];

        $validator = Validator::make($input, $rules);
        if($validator->fails())
        {
            return $validator;
        }

        $cliente = new Cliente();
        $cliente->fill($input);
        $cliente->save();

        return $cliente;
    }

    public function getCliente($id)
    {
        $cliente = self::findOrNew($id);
        if (empty($cliente->nome))
        {
            return false;
        }

        return $cliente;
    }

    public function updateCliente($id)
    {
        $cliente = self::findOrNew($id);
        if(empty($cliente->nome))
        {
            return false;
        }

        $input = Input::all();
        $cliente->fill($input);
        $cliente->save();

        return $cliente;
    }

    public function deleteCliente($id)
    {
        $cliente = self::findOrNew($id);
        if (empty($cliente->nome))
        {
            return false;
        }

        return $cliente->delete();
    }

} 