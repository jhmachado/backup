<?php

class PessoaJuridicaService {

    private $pessoaJuridicaRepository;

    public function __construct(){
        $this->pessoaJuridicaRepository = new PessoaJuridicaRepository();
    }

    public function salvar(PessoaJuridica $pessoaJuridica){
        $pessoaJuridica->setUltimaModificacao();
        return $this->pessoaJuridicaRepository->save($pessoaJuridica);
    }

    public function listar(PessoaJuridica $pessoaJuridica){
        return $this->pessoaJuridicaRepository->findAll($pessoaJuridica);
    }

    public function buscar(PessoaJuridica $pessoaJuridica){
        return $this->pessoaJuridicaRepository->findById($pessoaJuridica);
    }

    public function alterar(PessoaJuridica $pessoaJuridica){
        $pessoaJuridica->setUltimaModificacao();
        return $this->pessoaJuridicaRepository->update($pessoaJuridica);
    }

    public function deletar(PessoaJuridica $pessoaJuridica){
        return $this->pessoaJuridicaRepository->delete($pessoaJuridica);
    }
} 