<?php

class Fornecedor extends Entidade{
    /*
     * @param string $nome
     */
    public $nome;


    public function __construct(){
        settype($this->nome, "string");
    }
}