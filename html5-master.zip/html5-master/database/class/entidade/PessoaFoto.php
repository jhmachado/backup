<?php

class PessoaFoto extends EntidadeFoto{

    public $pessoa;

    public function __construct(){

        settype($this->pessoa,   "object");

    }

    public function serializeArray($classe, array $array){
        echo '<pre>';
        var_dump($array);
        echo '</pre>';
    }

} 