<?php

class UsuarioRepository extends TRepository{
    public function __construct(){
        parent::__construct();
    }
}