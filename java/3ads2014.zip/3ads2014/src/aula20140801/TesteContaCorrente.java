package aula20140801;
import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.Test;


public class TesteContaCorrente {

	@Test
	public void testarSaldoInicial() {
		ContaCorrente cc1 = new ContaCorrente();
		BigDecimal saldo = cc1.getSaldo();
		
		assertEquals("Saldo deve ser zero!", new BigDecimal("0.00"), saldo);
		
	}
	@Test
	public void testarDeposito() {
		ContaCorrente cc1 = new ContaCorrente();
		
		cc1.depositar(new BigDecimal("1500.23"));
		
		assertEquals("Saldo incorreto!",new BigDecimal("1500.23"),cc1.getSaldo());
	}

	@Test
	public void testarSaque() {
		ContaCorrente cc1 = new ContaCorrente();
		
		cc1.sacar(new BigDecimal("1500.23"));
		
		assertEquals("Saldo incorreto!",new BigDecimal("-1500.23"),cc1.getSaldo());
	}
	
	@Test
	public void testarSeOsSaquesForamRegistrados() {
		ContaCorrente cc1 = new ContaCorrente();
		
		assertEquals("Deveria estar vazio!",0, cc1.getSaquesRegistrados().size());
		
		//List<BigDecimal> saques = cc1.getSaquesRegistrados();
		
		cc1.sacar(new BigDecimal("500.00"));
		assertEquals("Saque incorreto!",new BigDecimal("500.00"),cc1.getSaquesRegistrados().get(0));
		
		cc1.sacar(new BigDecimal("400.00"));
		assertEquals("Saque incorreto!",new BigDecimal("400.00"),cc1.getSaquesRegistrados().get(1));
		
		cc1.sacar(new BigDecimal("300.00"));
		assertEquals("Saque incorreto!",new BigDecimal("300.00"),cc1.getSaquesRegistrados().get(2));
	}
	
	@Test
	public void testarSaqueEmDiaEspecifico() throws ParseException {
		ContaCorrente cc = new ContaCorrente();
		
		BigDecimal valorPrimeiroSaque = new BigDecimal("255.10");		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date dataPrimeiroSaque = dateFormat.parse("20/07/2014");		
		cc.sacar(dataPrimeiroSaque, valorPrimeiroSaque);
		
		BigDecimal valorSegundoSaque = new BigDecimal("122.10");		
		Date dataSegundoSaque = dateFormat.parse("21/07/2014");		
		cc.sacar(dataSegundoSaque, valorSegundoSaque);
		
		BigDecimal valorTerceiroSaque = new BigDecimal("127.10");		
		Date dataTerceiroSaque = dateFormat.parse("21/07/2014");		
		cc.sacar(dataTerceiroSaque, valorTerceiroSaque);
		
		List<BigDecimal> saquesDoDia21 = cc.getSaquesRegistrados(dataSegundoSaque);
		BigDecimal totalSaquesDia21 = new BigDecimal("0.00");
		for (BigDecimal valor : saquesDoDia21) {
			totalSaquesDia21 = totalSaquesDia21.add(valor);
		}
		BigDecimal valorEsperado = valorSegundoSaque.add(valorTerceiroSaque);
		assertEquals("Saldo do dia 21/07/2014 incorreto!",valorEsperado, totalSaquesDia21);
	}
	@Test
	public void testarDepositoEmDiaEspecifico() throws ParseException {
		ContaCorrente cc = new ContaCorrente();
		
		BigDecimal valorPrimeiroDeposito = new BigDecimal("255.10");		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date dataPrimeiroDeposito = dateFormat.parse("20/07/2014");		
		cc.depositar(dataPrimeiroDeposito, valorPrimeiroDeposito);
		
		BigDecimal valorSegundoDeposito = new BigDecimal("122.10");		
		Date dataSegundoDeposito = dateFormat.parse("21/07/2014");		
		cc.depositar(dataSegundoDeposito, valorSegundoDeposito);
		
		BigDecimal valorTerceiroDeposito = new BigDecimal("127.10");		
		Date dataTerceiroDeposito = dateFormat.parse("21/07/2014");		
		cc.depositar(dataTerceiroDeposito, valorTerceiroDeposito);
		
		List<BigDecimal> DepositosDoDia21 = cc.getDepositosRegistrados(dataSegundoDeposito);
		BigDecimal totalDepositosDia21 = new BigDecimal("0.00");
		for (BigDecimal valor : DepositosDoDia21) {
			totalDepositosDia21 = totalDepositosDia21.add(valor);
		}
		BigDecimal valorEsperado = valorSegundoDeposito.add(valorTerceiroDeposito);
		assertEquals("Saldo do dia 21/07/2014 incorreto!",valorEsperado, totalDepositosDia21);
	}
	
	
	
	
}




