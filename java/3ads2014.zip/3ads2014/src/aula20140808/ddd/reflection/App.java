package aula20140808.ddd.reflection;

public class App {
	
	public static void main(String[] args) {
		
		PaisRepository repoPais = 
				(PaisRepository) RepositoryFactory.newInstance(PaisRepository.class);
		
		repoPais.findBySiglaAndNome("CA", "Canada");
		repoPais.findBySiglaAndNome("JP", "Jap�o");
		repoPais.findBySiglaAndNomeOrIdOrderByDesc("JP", "Jap�o",999L);
		
	}

}
