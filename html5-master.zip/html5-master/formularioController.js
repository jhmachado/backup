var controllers = angular.module('controllers', []);

function FormularioController($scope, $http){

    $scope.formulario = {};

    $scope.validaFormularioSalvo = function(){
        if(validaChave("form")){

        }else{
            localStorage.setItem("form", "");
        }
    };

    $scope.salvaAlteracao = function(){

    };


    
}

controllers.controller('FormularioController', ['$scope, $http', FormularioController]);