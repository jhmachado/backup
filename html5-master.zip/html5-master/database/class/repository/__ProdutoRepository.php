<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 07/01/15
 * Time: 22:08
 */

class ProdutoRepository {

}