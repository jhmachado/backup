<?php

class ProfissaoService {

    private $profissaoRepository;

    public function __construct(){
        $this->profissaoRepository = new ProfissaoRepository();
    }

    public function salvar(Profissao $profissao){
        $profissao->setUltimaModificacao();
        return $this->profissaoRepository->save($profissao);
    }

    public function listar(Profissao $profissao){
        return $this->profissaoRepository->findAll($profissao);
    }

    public function buscar(Profissao $profissao){
        return $this->profissaoRepository->findById($profissao);
    }

    public function alterar(Profissao $profissao){
        $profissao->setUltimaModificacao();
        return $this->profissaoRepository->update($profissao);
    }

    public function deletar(Profissao $profissao){
        return $this->profissaoRepository->delete($profissao);
    }
} 