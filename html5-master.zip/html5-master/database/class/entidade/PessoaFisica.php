<?php


class PessoaFisica extends Entidade{

    /*
     *  @param string rg da pessoa - $rg
     *  @param string cpf da pessoa - $cpf
     *  @param string data de nascimento da pessoa - $dataDeNascimento
     *  @param string sobrenome da pessoa - $sobrenome
     *  @param string sexo da pessoa - $sexo
     */

    public $rg;
    public $cpf;
    public $dataDeNascimento;
    public $sobrenome;
    public $sexo;

    public function __construct(){
        settype($this->rg, "string");
        settype($this->cpf, "string");
        settype($this->dataDeNascimento, "string");
        settype($this->sobrenome, "string");
        settype($this->sexo, "string");
    }

    public function validaDataDeNascimento(){
        return (strtotime(Date('Y-m-d')) > strtotime($this->dataDeNascimento));
    }
} 