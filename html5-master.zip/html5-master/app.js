'use strict'

angular.module('controllers', []);

var erp = angular.module('erp', []);
erp.config([
    '$httpProvider',
    function($httpProvider){
        $httpProvider.interceptors.push('AuthInterceptor');
    }
]);

erp.factory('AuthInterceptor', ['$q',
    AuthInterceptor
]);


function AuthInterceptor($q, $window){
    return{
        responseError: function(rejection){
            var data = rejection.data;

            if(data.message){
                console.log(data.message);
            }

            if(data.messageDeveloper){
                console.log(data.messageDeveloper);
            }

            return $q.reject(rejection);
        }
    };
}
