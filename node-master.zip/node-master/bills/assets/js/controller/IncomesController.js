var controllers = angular.module('controllers', []);

function IncomesController($scope, $http){

    $scope.path = window.location.protocol + "//" + window.location.host + "/";

    $scope.editing = false;
    $scope.current = {
        title : '',
        date : '',
        value : ''
    };
    $scope.incomes = [];


    $scope.init = function()  {
        console.log('init', $scope.path);
    };

    io.socket.get('/income', function(data){
        $scope.incomes = data;
        $scope.$apply();
    });

    io.socket.on('income', function(event){
        switch(event.verb){
            case 'created':
                $scope.incomes.push(event.data);
                $scope.$apply();
                break;
        }

    });

    $scope.select = function(income) {
        $scope.editing = true;
        $scope.current = income;
        //$scope.$apply();
    };

    $scope.update = function() {
        console.log('updating income...')
        var path = $scope.path + "income/" + $scope.current.id;

        $http.put(path, $scope.current)
            .success(function(data, status){
                console.log(data);
                $scope.current = {};
                $scope.editing = false;
            })
            .error(function(data){
                console.log(data);
            });
    };

    $scope.saveIncome = function() {

        console.log('saving income...')
        var path = $scope.path + "income/create/";

        $http.post(path, $scope.current)
            .success(function(data, status){
                console.log(data);
            })
            .error(function(data){
                console.log(data);
            });
    };
}

controllers.controller('IncomesController', ['$scope, $http', IncomesController]);