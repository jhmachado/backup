<?php

class PessoaJuridica extends Entidade{

    /*
     *  @param string razao social - $razaoSocial
     *  @param string inscricao estadual - $inscricaoEstadual
     *  @param string inscricao municipal - $inscricaoMunicipal
     *  @param string cnpj - $cnpj
     *  @param string data de abertura - $dataDeAbertura
     */

    public $razaoSocial;
    public $inscricaoEstadual;
    public $inscricaoMunicipal;
    public $cnpj;
    public $dataDeAbertura;


    public function __construct(){
        settype($this->razaoSocial, "string");
        settype($this->inscricaoEstadual, "string");
        settype($this->inscricaoMunicipal, "string");
        settype($this->cnpj, "string");
        settype($this->dataDeAbertura, "string");
    }
} 