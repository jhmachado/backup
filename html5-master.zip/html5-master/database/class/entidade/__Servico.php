<?php

class Servico extends Entidade{

    /*
     * @param string titulo
     * @param string texto
     */

    public $titulo;
    public $texto;

    public function __construct(){
        settype($this->titulo, "string");
        settype($this->texto, "string");
    }
}