function isSiteOnline(){
    return false;
}
