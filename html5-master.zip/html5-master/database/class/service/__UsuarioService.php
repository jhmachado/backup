<?php

class UsuarioService {

    private $usuarioRepository;

    public function __construct(){
        $this->usuarioRepository = new UsuarioRepository();
    }

    public function salvar(Usuario $usuario){
        $usuario->setMd5();
        $usuario->setUltimaModificacao();
        return $this->usuarioRepository->save($usuario);
    }

    public function listar(Usuario $usuario){
        return $this->usuarioRepository->findAll($usuario);
    }

    public function buscar(Usuario $usuario){
        $resultado = $this->usuarioRepository->findById($usuario);
        unset($resultado->senha);
        return $resultado;
    }

    public function alterar(Usuario $usuario){
        $usuario->setMd5();
        $usuario->setUltimaModificacao();
        return $this->usuarioRepository->update($usuario);
    }

    public function deletar(Usuario $usuario){
        return $this->usuarioRepository->delete($usuario);
    }
}