<?php

class Cliente extends Entidade{

    public $nome;
    public $email;
    public $telefone;

    public function __construct(){
        settype($this->nome, "string");
        settype($this->email, "string");
        settype($this->telefone, "string");
    }

}