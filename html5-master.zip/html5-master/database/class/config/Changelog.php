<?php

class Changelog {

    public $entidades;
    public $conexao;

    public function __construct(){
        #$this->listaEntidades();
        #$this->validarBanco();
    }

    public function validarBanco(){
        try{
            #$arquivoXMLMaster = PASTA.'/admin/class/config/database/changelog-master.xml';
            #$master = new SimpleXMLElement($arquivoXMLMaster);
        }catch (Exception $e){
            echo "Arquivo XML não existe ou está corrompido!";
        }
    }

    public function listaEntidades(){
        $entidades = scandir(PASTA."/admin/class/entidade", 1);
        unset($entidades[sizeof($entidades) -1]);
        unset($entidades[sizeof($entidades) -1]);

        foreach ($entidades as $entidade) {
            $nomeClasse = str_replace(".php", "", $entidade);
            $obj = new $nomeClasse();
            $parent = get_parent_class($obj);
            if($parent == "Entidade"){
                $this->entidades[] = array("titulo" => $nomeClasse);
                $this->listaAtributos($nomeClasse, $obj);
            }
        }

        unset($obj);
    }


    public function listaAtributos($nomeClasse, $obj){

    }
}