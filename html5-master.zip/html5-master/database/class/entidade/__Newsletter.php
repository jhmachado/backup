<?php

class Newsletter extends Entidade{

    /*
     * @param string email
     */

    public $email;

    public function __construct(){
        settype($this->email, "string");
    }
}