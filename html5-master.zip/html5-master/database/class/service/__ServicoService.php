<?php

class ServicoService {

    private $servicoRepository;

    public function __construct(){
        $this->servicoRepository = new ServicoRepository();
    }

    public function salvar(Servico $servico){
        $servico->setUltimaModificacao();
        return $this->servicoRepository->save($servico);
    }

    public function listar(Servico $servico){
        return $this->servicoRepository->findAll($servico);
    }

    public function buscar(Servico $servico){
        return $this->servicoRepository->findById($servico);
    }

    public function alterar(Servico $servico){
        $servico->setUltimaModificacao();
        return $this->servicoRepository->update($servico);
    }

    public function deletar(Servico $servico){
        return $this->servicoRepository->delete($servico);
    }
}