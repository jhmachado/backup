package aula20140801;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class ContaCorrente { 

	private BigDecimal saldo;
	private List<Movimento> movimentos;
	
	
	public ContaCorrente() {
		this.saldo = new BigDecimal("0.00");
		this.movimentos = new ArrayList<>();
	}

	public BigDecimal getSaldo() {
		return this.saldo ;
	}

	public void depositar(BigDecimal valor) {
		this.depositar(new Date(), valor);
	}
	
	public void depositar(Date data, BigDecimal valor) {
		this.saldo = this.saldo.add(valor);
		this.movimentos.add(new Deposito(valor, data));
	}

	public void sacar(BigDecimal valor) {
		this.sacar(new Date(), valor);
	}
	public void sacar(Date data, BigDecimal valor) {
		this.saldo = this.saldo.subtract(valor);
		this.movimentos.add(new Saque(valor,data)); 
	}

	public List<BigDecimal> getSaquesRegistrados() {
		return this.getSaquesRegistrados(null);
	}

	public List<BigDecimal> getSaquesRegistrados(Date data) {
		return getMovimentoEspecificoNaData(data, getSaques());
	}
	public List<BigDecimal> getDepositosRegistrados(Date data) {
		return getMovimentoEspecificoNaData(data, getDepositos());
	}

	private List<BigDecimal> getMovimentoEspecificoNaData(Date data, List<? extends Movimento> lista) {
		ArrayList<BigDecimal> valoresDosSaques = new ArrayList<>();
		boolean considerarQualquerData = (data == null);		
		
		for (Movimento m : lista) {
			if (considerarQualquerData || m.getData().equals(data)) {
				valoresDosSaques.add(m.getValor());
			}
		}
		
		return Collections.unmodifiableList(valoresDosSaques);
	}

	private List<Saque> getSaques() {
		List<Saque> saques = new ArrayList<>();
		for (Movimento m : this.movimentos) {
			if (m instanceof Saque) {
				saques.add( (Saque)m );
			}
		}
		return saques;
	}
	private List<Deposito> getDepositos() {
		List<Deposito> depositos = new ArrayList<>();
		for (Movimento m : this.movimentos) {
			if (m instanceof Deposito) {
				depositos.add( (Deposito)m );
			}
		}
		return depositos;
	}


}
