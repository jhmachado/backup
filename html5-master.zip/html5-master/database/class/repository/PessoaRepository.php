<?php

class PessoaRepository extends TRepository{

    public function __construct(){
        parent::__construct();

        $this->chavesEstrangeiras[] = "PessoaFisica";
        $this->chavesEstrangeiras[] = "PessoaJuridica";
        $this->arquivos[] = "fotos";

        $this->order = "nome";
    }
}