<?php

class Capacidade extends Entidade {


    /*
     *  @param string titulo da profissao - $titulo
     *  @param string descricao da profissao - $descricao
     */

    public $titulo;
    public $descricao;

    public function __construct(){
        settype($this->titulo, "string");
        settype($this->descricao, "string");
    }

} 