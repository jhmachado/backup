package aula20140805;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public interface MovimentoRepository {

	void salvar(Movimento movimento);

	List<BigDecimal> findSaquesByData(Date data);

	List<BigDecimal> findDepositosByData(Date data);

}
