package aula20140808.ddd.associacoesComIDs;

import java.util.List;

public class UfRepository {


	public List<Uf> findByPaisId(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

}
