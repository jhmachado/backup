<?php

class Profissional extends Entidade{

    /*
     *  @param Profissao do profissional - $profissao
     *  @param Pessoa cadastrado basico - $pessoa
     *  @param Profissional superior imediato - $superior
     *  @param float salario do profissional - $salario
     */

    public $profissao;
    public $pessoa;
    public $superior;
    public $salario;

    public function __construct(){
        settype($this->profissaom, "object");
        settype($this->profissaom, "object");
        settype($this->profissaom, "object");
        settype($this->profissaom, "float");
    }
} 