<?php

class Pedido extends Entidade{

    /*
     * @param Cliente $cliente
     *
     */
    public $cliente;
    public $itens = array();


    public function __construct(){
        settype($this->cliente, "string");
    }
}