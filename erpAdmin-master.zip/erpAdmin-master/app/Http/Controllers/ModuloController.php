<?php

namespace App\Http\Controllers;

use App\Modulo;
use App\Http\Controllers\Controller;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;

class ModuloController extends Controller{

    protected $modulo;

    public function __construct(Modulo $modulo)
    {
        $this->modulo = $modulo;
    }

    public function allModulos()
    {
        return response()->json($this->modulo->allModulos(), 200);
    }

    public function getModulo($id)
    {
        $modulo = $this->modulo->getModulo($id);
        if (!$modulo)
        {
            return response()->json(['response' => 'Módulo não encontrado!'], 400);
        }

        return response()->json($modulo, 200);
    }
    
    public function saveModulo()
    {
        return response()->json($this->modulo->saveModulo(), 200);
    }

    public function updateModulo($id)
    {
        $modulo = $this->modulo->updateModulo($id);
        if (!$modulo)
        {
            return response()->json(['response' => 'Módulo não encontrado!'], 400);
        }

        return response()->json($modulo, 200);
    }

    public function deleteModulo($id)
    {
        $modulo = $this->modulo->deleteModulo($id);
        if (!$modulo)
        {
            return response()->json(['response' => 'Módulo não encontrado!'], 400);
        }

        return response()->json(['response' => 'Módulo removido com sucesso!'], 200);
    }
} 