package aula20140805;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class ContaCorrente { 

	private BigDecimal saldo;
	private MovimentoRepository repoMovimento = MovimentoReporitoryFactory.createRepository();
		
	public ContaCorrente() {
		this.saldo = new BigDecimal("0.00");
	}

	public BigDecimal getSaldo() {
		return this.saldo ;
	}

	public void depositar(BigDecimal valor) {
		this.depositar(new Date(), valor);
	}
	
	public void depositar(Date data, BigDecimal valor) {
		this.saldo = this.saldo.add(valor);
		this.repoMovimento.salvar(new Deposito(valor, data));
	}

	public void sacar(BigDecimal valor) {
		this.sacar(new Date(), valor);
	}
	public void sacar(Date data, BigDecimal valor) {
		this.saldo = this.saldo.subtract(valor);
		this.repoMovimento.salvar(new Saque(valor,data)); 
	}

	public List<BigDecimal> getSaquesRegistrados() {
		return this.getSaquesRegistrados(null);
	}

	public List<BigDecimal> getSaquesRegistrados(Date data) {
		return this.repoMovimento.findSaquesByData(data);
	}
	public List<BigDecimal> getDepositosRegistrados(Date data) {
		return this.repoMovimento.findDepositosByData(data);
	}

}
