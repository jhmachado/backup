@extends('layouts.app')

@section('content')

<div id="content" class="right">
    <div class="charts">

        <div class="breadcrumbs clearfix">
            <ul class="breadcrumbs left">
                <li><a href="">ERP ADMIN</a></li>
                <li><i class="fa fa-angle-right"></i></li>
                <li>CLIENTES</li>
                <li><i class="fa fa-angle-right"></i></li>
                <li><a href="clientes/form">ADICIONAR</a></li>
            </ul>

            <a href="#" class="btn right"><i class="fa fa-caret-square-o-left"></i>EXPORTAR</a>
        </div>

        <form action="" method="post">
            <div class="inner clearfix">

	            <fieldset class="error">
                    <label for="nome">NOME</label>
                    <div class="field">
                        <input type="text" name="nome" id="nome" value="">
                        <span class="error-alert">PREENCHA ESSE CAMPO</span>
                    </div>
                </fieldset>

<!--	            <fieldset class="error">-->
<!--                    <label for="login">LOGIN</label>-->
<!--                    <div class="field">-->
<!--                        <input type="text" name="login" value="--><?//= $_POST['login'] ?><!--">-->
<!--                        <span class="error-alert">PREENCHA ESSE CAMPO</span>-->
<!--                    </div>-->
<!--                </fieldset>-->
<!---->
<!--	            <fieldset class="error">-->
<!--                    <label for="nome">E-MAIL</label>-->
<!--                    <div class="field">-->
<!--                        <input type="text" name="email" id="email" value="--><?//= $_POST['email'] ?><!--">-->
<!--                        <span class="error-alert">PREENCHA ESSE CAMPO</span>-->
<!--                    </div>-->
<!--                </fieldset>-->

                <input type="submit" name="filtrar" value="FILTRAR" class="right">
            </div>
        </form>

        <form action="" method="post">
            <div class="tables clearfix">
                <table class="datatable adm-table">

                    <thead>
                    <tr>
                        <th><input type="checkbox" data-label="" class="select-all"></th>
                        <th>NOME                    <span class="order"></span></th>
                        <th>AÇÕES                   <span class="order"></span></th>
                    </tr>
                    </thead>

                    <tbody>

                    @foreach ($clientes as $cliente)

                    <tr>
                        <td>
                            <input type="checkbox" value="{{ $cliente->id }}" name="excluir[]" data-label="">
                        </td>

                        <td>
                            <a href="cliente/form/{{ $cliente->id }}">
                                <p>{{ $cliente->nome }}</p>
                            </a>
                        </td>

                        <td align="right">
                            <a href="configuracoes/cliente/form/{{ $cliente->id  }}" class="edit">
                                <i class="fa fa-pencil"></i>
                            </a>
                        </td>
                    </tr>

                    @endforeach

                    </tbody>
                </table>

                <input type="submit" name="excluir" value="EXCLUIR">
            </div>
        </form>
    </div>
</div>

@endsection