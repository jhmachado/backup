<?php

class ProfissaoRepository extends TRepository{
    public function __construct(){
        parent::__construct();
    }
}