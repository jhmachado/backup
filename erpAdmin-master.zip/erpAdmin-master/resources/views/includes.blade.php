<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<title>ERP Admin</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- CSS ================================================== -->
<link rel="stylesheet" href="lib/css/style.css">

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->

<!-- FONTS ================================================== -->

<!-- Favicons ================================================== -->
<link rel="shortcut icon" href="imagem/favicon.ico">

<script src="lib/js/jquery.min.js"></script>
<script src="lib/js/jquery-ui.min.js"></script>
<script src="lib/js/libs/bootstrap.min.js"></script>
<script src="lib/js/libs/waypoints.js"></script>
<script src="lib/js/libs/jquery.counterup.min.js"></script>
<script src="lib/js/libs/chosen.jquery.min.js"></script>
<script src="lib/js/libs/input.slider.js"></script>
<script src="lib/js/libs/bxslider.js"></script>
<script src="lib/js/libs/prettyCheckable.min.js"></script>
<script src="lib/js/libs/jquery.dataTables.min.js"></script>
<script src="lib/js/libs/chartist/chartist.min.js"></script>
<script src="lib/js/libs/chartist/chartist-plugin-tooltip.js"></script>
<script src="lib/js/libs/datepicker/moment.min.js"></script>
<script src="lib/js/libs/datepicker/bootstrap-datetimepicker.min.js"></script>
<script src="lib/js/libs/jquery.matchHeight-min.js"></script>
<script src="lib/js/libs/jquery.fileupload.js"></script>
<script src="lib/js/libs/fileStyle.js"></script>
<script src="lib/js/libs/tagsInput.js"></script>
<script src="lib/js/plugins.js"></script>
<script src="lib/js/charts.js"></script>
<script src="lib/js/upload.js"></script>
<script src="lib/js/app.js"></script>

{{--<script src="lib/js/angular.js"></script>--}}
{{--<script src="lib/js/appAdmin.js"></script>--}}
{{--<script src="lib/js/controller/clienteController.js"></script>--}}