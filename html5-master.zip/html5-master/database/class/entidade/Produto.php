<?php

class Produto extends Entidade{

    /*
     * @param string $nome
     * @param float $valor
     * @param Fornecedor $fornecedor
     */
    public $nome;
    public $valor;
    public $fornecedor;
    public $partes;

    public function __construct(){

    }

}