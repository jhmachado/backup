<?php

class AutoloadService extends Autoload{

    public $autoloadRepository;
    public $pasta;
    public $proximaPasta;

    public function __construct($pasta){
        $this->pasta = $pasta;
        $this->proximaPasta = $pasta;
        $this->pasta .= "class/service";
        spl_autoload_register(array($this, 'loader'));
    }

    public function loader($className){
        $nomeArquivo = "$this->pasta/".$className . '.php';
        if(is_file($nomeArquivo)) {
            include $nomeArquivo;
        }else{
            $this->proximo();
        }
    }

    public function proximo(){
        require_once 'AutoloadRepository.php';
        $this->autoloadRepository = new AutoloadRepository($this->proximaPasta);
    }
}