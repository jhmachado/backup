package aula20140729;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ContaCorrente {

	private BigDecimal saldo;
	private List<BigDecimal> saques;
	
	
	public ContaCorrente() {
		this.saldo = new BigDecimal("0.00");
		this.saques = new ArrayList<>();
	}

	public BigDecimal getSaldo() {
		return this.saldo ;
	}

	public void depositar(BigDecimal valor) {
		this.saldo = this.saldo.add(valor);
	}

	public void sacar(BigDecimal valor) {
		this.saldo = this.saldo.subtract(valor);
		this.saques.add(valor);
	}

	public List<BigDecimal> getSaquesRegistrados() {
		//return Collections.unmodifiableList(this.saques);
		return Collections.unmodifiableList(new ArrayList<>(this.saques));
	}
}
