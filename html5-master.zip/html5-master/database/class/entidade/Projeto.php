<?php

class Projeto extends Entidade {

    /*
     * @param string titulo do projeto - $titulo
     * @param string data de inicio do projeto - $inicio
     * @param string data de termino do projeto - $fim
     * @param string data de entrega para o cliente - $entrega
     * @param EstadoProjeto estado atual do projeto dentro do processo - $estadoDoProjeto
     * @param EtapaProjeto etapa em que o projeto se encontra - $etapaAtual
     * @param float custo total do projeto - $custoTotal
     * @param Profissional responsavel pelo projeto na empresa - $responsavel
     * @param cliente $cliente
     */

    public $titulo;
    public $inicio;
    public $fim;
    public $entrega;
    public $estadoDoProjeto;
    public $etapaAtual;
    public $custoTotal;
    public $responsavel;
    public $cliente;
    public $produto;

    public function __construct(){
        settype($this->titulo, "string");
        settype($this->inicio, "string");
        settype($this->fim, "string");
        settype($this->entregap, "string");
        settype($this->estadoDoProjeto, "object");
        settype($this->etapaAtual, "object");
        settype($this->custoTotal, "float");
        settype($this->responsavel, "object");
        settype($this->cliente, "object");
        settype($this->produto, "object");
    }
} 