package aula20140805;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class MovimentoRepositoryInMemory implements MovimentoRepository {
	private List<Movimento> movimentos = new ArrayList<>();

	@Override
	public void salvar(Movimento movimento) {
		this.movimentos.add(movimento);
	}

	@Override
	public List<BigDecimal> findSaquesByData(Date data) {
		return this.getMovimentoEspecificoNaData(data, getSaques());
	}

	@Override
	public List<BigDecimal> findDepositosByData(Date data) {
		return this.getMovimentoEspecificoNaData(data, getDepositos());
	}
	private List<Saque> getSaques() {
		List<Saque> saques = new ArrayList<>();
		for (Movimento m : this.movimentos) {
			if (m instanceof Saque) {
				saques.add( (Saque)m );
			}
		}
		return saques;
	}
	private List<Deposito> getDepositos() {
		List<Deposito> depositos = new ArrayList<>();
		for (Movimento m : this.movimentos) {
			if (m instanceof Deposito) {
				depositos.add( (Deposito)m );
			}
		}
		return depositos;
	}

	private List<BigDecimal> getMovimentoEspecificoNaData(Date data, List<? extends Movimento> lista) {
		ArrayList<BigDecimal> valoresDosSaques = new ArrayList<>();
		boolean considerarQualquerData = (data == null);		
		
		for (Movimento m : lista) {
			if (considerarQualquerData || m.getData().equals(data)) {
				valoresDosSaques.add(m.getValor());
			}
		}
		
		return Collections.unmodifiableList(valoresDosSaques);
	}
}
