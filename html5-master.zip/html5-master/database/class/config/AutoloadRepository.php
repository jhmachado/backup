<?php

class AutoloadRepository extends Autoload {

    public $pasta;
    public $proximaPasta;
    public $autoloadConfig;

    public function __construct($pasta){
        $this->pasta = $pasta;
        $this->proximaPasta = $pasta;
        $this->pasta .= "class/repository";
        spl_autoload_register(array($this, 'loader'));
    }

    public function loader($className){
        $nomeArquivo = "$this->pasta/".$className . '.php';
        if(is_file($nomeArquivo)) {
            include $nomeArquivo;
        }else{
            $this->proximo();
        }
    }

    public function proximo(){
        require_once 'AutoloadConfig.php';
        $this->autoloadConfig = new AutoloadConfig($this->proximaPasta);
    }
}