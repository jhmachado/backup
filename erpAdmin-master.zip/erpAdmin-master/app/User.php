<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function login()
    {
        $rules = array(
            'email'    => 'required|string',
            'password' => 'required'
        );

        $input = Input::all();
        $input['password'] = Hash:: make($input['password']);
        unset($input['logar']);

        $validator = Validator::make($input, $rules);
        if ($validator->fails()) {
            return 'Validator';
        }

        if (Auth::attempt($input)) {
            return "";
        }

        return 'Login';
    }
}
