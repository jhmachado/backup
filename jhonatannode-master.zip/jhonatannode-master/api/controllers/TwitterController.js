/**
 * TwitterController
 *
 * @description :: Server-side logic for managing twitters
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
	handleLogin : function (req, res) {
		req.session.me = 'fsdjfldsf';
		return res.ok();
	}

};

