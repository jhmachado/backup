<?php

class ConfigRepository  extends TRepository{
    public function __construct(){
        parent::__construct();
    }
}