@extends('../layouts.app')

@section('content')

<div id="content" class="right">
    <div class="charts">

        <div class="breadcrumbs clearfix">
            <ul class="breadcrumbs left">
                <li><a href="">ERP ADMIN</a></li>
                <li><i class="fa fa-angle-right"></i></li>
                <li>
                    <a href="clientes/">CLIENTES</a>
                </li>
                <li><i class="fa fa-angle-right"></i></li>
                <li>ADICIONAR</li>
            </ul>
        </div>

        <form action="" method="post">
            <div class="inner clearfix">

                <fieldset class="error">
                    <label for="titulo">NOME</label>
                    <div class="field">
                        <input type="text" name="nome" value="{{ $cliente->nome }}?>">
                        <span class="error-alert">PREENCHA ESSE CAMPO</span>
                    </div>
                </fieldset>

                <div>
                    <div class="dotted">

                        <h2> Conexão </h2>

                        <fieldset class="error">
                            <label for="host">HOST</label>
                            <div class="field">
                                <input type="text" name="mysql_host" value="{{ $cliente->mysql_host  }}">
                                <span class="error-alert">PREENCHA ESSE CAMPO</span>
                            </div>
                        </fieldset>

                        <fieldset class="error">
                            <label for="banco">NOME DO BANCO</label>
                            <div class="field">
                                <input type="text" name="mysql_base" value="{{ $cliente->mysql_base }}">
                                <span class="error-alert">PREENCHA ESSE CAMPO</span>
                            </div>
                        </fieldset>

                        <fieldset class="error">
                            <label for="usuario">USUÁRIO</label>
                            <div class="field">
                                <input type="text" name="mysql_user" value="{{ $cliente->mysql_user }}">
                                <span class="error-alert">PREENCHA ESSE CAMPO</span>
                            </div>
                        </fieldset>


                        <fieldset class="error">
                            <label for="senha">SENHA</label>
                            <div class="field">
                                <input type="password" name="mysql_pass" value="{{ $cliente->mysql_pass }}">
                                <span class="error-alert">PREENCHA ESSE CAMPO</span>
                            </div>
                        </fieldset>


                        <fieldset class="error">
                            <label for="cookie">COOKIE</label>
                            <div class="field">
                                <input type="text" name="cookie" value="{{ $cliente->cookie }}">
                                <span class="error-alert">PREENCHA ESSE CAMPO</span>
                            </div>
                        </fieldset>

                    </div>
                </div>

                <div style="clear: both;"></div>

                <input type="submit" name="salvar" value="SALVAR" class="right">
                <a href="clientes/" class="cancel right">VOLTAR</a>
            </div>
        </form>

    </div>
</div>

@endsection
