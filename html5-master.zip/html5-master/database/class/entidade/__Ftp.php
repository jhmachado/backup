<?php

class Ftp extends Entidade {

    public $host;
    public $usuario;
    public $senha;

    public function __constrct(){
        settype($this->host, "string");
        settype($this->usuario, "string");
        settype($this->senha, "string");
    }

    public function testar(){
        $con = ftp_connect($this->host, 21) or die("Não foi possível conectar a $this->host ");
        /*if(!$con){
            return "Não foi possível conectar ao servidor";
        }*/
        $login = ftp_login($con, $this->usuario, $this->senha);
        if(!$login){
            return "Login incorreto";
        }
        return "Conexão bem sucedida";
    }

}